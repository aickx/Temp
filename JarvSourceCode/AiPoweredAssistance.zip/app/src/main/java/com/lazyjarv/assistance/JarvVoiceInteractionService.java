package com.lazyjarv.assistance;
import android.content.Intent;

import com.lazyjarv.assistance.JarvVoiceInteractionSession;
import android.service.voice.VoiceInteractionService;

public class JarvVoiceInteractionService extends VoiceInteractionService {

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // When user swipes app from Recents, stop the service cleanly
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onShutdown() {
        // Called by the system when this VoiceInteractionService is being shut down
        super.onShutdown();
    }
}

