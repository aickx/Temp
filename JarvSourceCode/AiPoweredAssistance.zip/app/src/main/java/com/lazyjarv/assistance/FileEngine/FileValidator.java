package com.lazyjarv.assistance.FileEngine;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.lazyjarv.assistance.Utils;

public class FileValidator {

    public static final Map<String, String> fuzzyResolutionCache = new ConcurrentHashMap<>();

    public static void validateOutput(String op, File rawFile, File verifyDst) throws IOException {
        switch (op) {
            case "mkdir": case "create": case "copy": case "move":
            case "rename": case "zip": case "unzip": case "encrypt": case "decrypt":
                if (!verifyDst.exists())
                    throw new IOException("Validation failed: Output not created.");
                if ((op.equals("encrypt") || op.equals("decrypt") || op.equals("zip")) && verifyDst.length() == 0)
                    throw new IOException("Critical: Target is empty 0-byte file.");
                break;
            case "delete": case "shred":
                if (rawFile.exists())
                    throw new IOException("Deletion failed: File still on disk.");
                break;
        }
    }

    public static String checkAndSuggest(File rawFile) {
        File parentDir = rawFile.getParentFile();
        if (parentDir != null && parentDir.exists() && parentDir.listFiles() != null) {
            File best = null; int bestDist = 4;
            for (File c : parentDir.listFiles()) {
                int d = Utils.getFuzzyDistance(rawFile.getName(), c.getName());
                if (d < bestDist) { bestDist = d; best = c; }
            }
            if (best != null) {
                fuzzyResolutionCache.put(rawFile.getName().toLowerCase(), best.getName());
                return " Did you mean: " + best.getName() + "?";
            }
        }
        return "";
    }
}