package com.lazyjarv.assistance;

import android.content.Context;
import android.content.Intent;
import android.content.pm.*;
import java.util.List;

public class AppManager {

    private volatile String appData = "";

    public void loadApps(final Context ctx) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    PackageManager pm = ctx.getPackageManager();
                    Intent intent = new Intent(Intent.ACTION_MAIN, null);
                    intent.addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> apps = pm.queryIntentActivities(intent, 0);
                    StringBuilder sb = new StringBuilder();
                    for (ResolveInfo info : apps) {
                        sb.append(info.loadLabel(pm).toString().toLowerCase().trim())
                          .append(":::")
                          .append(info.activityInfo.packageName.toLowerCase().trim())
                          .append("|||");
                    }
                    appData = sb.toString();
                } catch (Exception e) {}
            }
        }).start();
    }

    public String getAppData() { return appData; }

    public String findPackage(String targetApp) {
        if (targetApp == null || targetApp.isEmpty() || appData.isEmpty()) return "";
        for (String app : appData.split("\\|\\|\\|")) {
            if (app.contains(":::")) {
                String[] parts = app.split(":::");
                if (parts.length >= 2) {
                    String label = parts[0], pkg = parts[1];
                    if (label.contains(targetApp) || targetApp.contains(label) || pkg.contains(targetApp))
                        return pkg;
                }
            }
        }
        return "";
    }
}