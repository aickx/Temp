package com.lazyjarv.assistance; // 😉 Matches your real package!

import android.service.voice.VoiceInteractionSessionService;
import android.service.voice.VoiceInteractionSession;

public class JarvVoiceInteractionSessionService extends VoiceInteractionSessionService {
    @Override
    public VoiceInteractionSession onNewSession(android.os.Bundle args) {
        return new JarvVoiceInteractionSession(this); // Will now resolve perfectly!
    }
}
