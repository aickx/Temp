package com.lazyjarv.assistance;

import java.util.ArrayList;
import org.json.*;

public class MemoryManager {

    private final ArrayList<String> chatHistory = new ArrayList<>();

    public ArrayList<String> getHistory() { return chatHistory; }

    public void addUserTurn(String text) {
        try {
            JSONObject turn = new JSONObject();
            JSONArray parts = new JSONArray();
            parts.put(new JSONObject().put("text", text));
            turn.put("parts", parts);
            turn.put("role", "user");
            chatHistory.add(turn.toString());
            enforceMemoryLimit(); // Triggers the cap
        } catch (Exception e) {}
    }

    public void addModelTurn(String text) {
        try {
            JSONObject turn = new JSONObject();
            JSONArray parts = new JSONArray();
            parts.put(new JSONObject().put("text", text));
            turn.put("parts", parts);
            turn.put("role", "model");
            chatHistory.add(turn.toString());
            enforceMemoryLimit(); // Triggers the cap
        } catch (Exception e) {}
    }

    // Add this new method to prevent token bloat
    private void enforceMemoryLimit() {
        // Keeps only the last 10 messages (5 user prompts + 5 AI responses)
        while (chatHistory.size() > 10) {
            chatHistory.remove(0); 
        }
    }
    
    public void clearMemory() {
    chatHistory.clear();
    }
}    
