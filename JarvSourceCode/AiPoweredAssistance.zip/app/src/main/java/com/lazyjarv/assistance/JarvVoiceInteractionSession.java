package com.lazyjarv.assistance;

import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import org.json.JSONObject;

public class JarvVoiceInteractionSession extends VoiceInteractionSession {

    private View rootView;
    private View micOrb;
    private TextView statusText;

    private VoiceManager voiceManager;
    private AssistantManager assistantManager;
    private ActionExecutor actionExecutor;
    private AppManager appManager;
    private MemoryManager memoryManager;
    private AIManager aiManager;

    private boolean includeAppsOnce = false;

    public JarvVoiceInteractionSession(android.content.Context context) {
        super(context);
    }

    @Override
    public View onCreateContentView() {

        rootView = LayoutInflater.from(getContext())
                .inflate(R.layout.jarv_assistant_session, null);

        micOrb = rootView.findViewById(R.id.micOrb);
        statusText = rootView.findViewById(R.id.statusText);

        appManager = new AppManager();
        appManager.loadApps(getContext());

        actionExecutor = new ActionExecutor(getContext(), appManager);

        memoryManager = new MemoryManager();

        aiManager = new AIManager(
                null,
                new AIManager.AICallback() {

                    @Override
                    public void onSpeechReady(String speech) {
                        statusText.setText(speech);

                        if (voiceManager != null) {
                            voiceManager.speak(speech);
                        }
                    }

                    @Override
                    public void onActionReady(JSONObject liveReply) {
                        actionExecutor.execute(liveReply);
                    }

                    @Override
                    public void onError(String message) {
                        statusText.setText(message);
                    }

                    @Override
                    public String getAppData() {
                        return appManager.getAppData();
                    }

                    @Override
                    public boolean shouldIncludeApps() {
                        return includeAppsOnce;
                    }

                    @Override
                    public void setIncludeApps(boolean value) {
                        includeAppsOnce = value;
                    }

                    @Override
                    public void onNeedAppList(String userInput) {

                        includeAppsOnce = true;

                        aiManager.send(
                                userInput,
                                JarvConfig.GEMINI_API_KEY,
                                JarvConfig.SYSTEM_PROMPT
                        );
                    }
                },
                memoryManager
        );

        voiceManager = new VoiceManager(
                getContext().getApplicationContext(),
                new VoiceManager.VoiceCallback() {

                    @Override
                    public void onResults(String text) {

                        statusText.setText("Processing...");

                        aiManager.send(
                                text,
                                JarvConfig.GEMINI_API_KEY,
                                JarvConfig.SYSTEM_PROMPT
                        );
                    }

                    @Override
                    public void onError(String error) {
                        statusText.setText(error);
                    }
                    @Override
                    public void onNoSpeechTimeout() {
                       hide();
                    }
                }
                
        );
        
        voiceManager.setSilenceDetection(true);
        voiceManager.setContinuousConversation(true); //<============ Voice manager Boolens =================

        assistantManager = new AssistantManager(
                voiceManager,
                null
        );

        startOrbAnimation();

        return rootView;
    }

@Override
public void onShow(Bundle args, int flags) {
    super.onShow(args, flags);

    // Tear down whatever the previous session left behind
    if (voiceManager != null) {
        voiceManager.cancelListening();
        voiceManager.shutdown();
        voiceManager = null;
    }

    // Always build a fresh VoiceManager for this showing
    voiceManager = new VoiceManager(
            getContext().getApplicationContext(),
            new VoiceManager.VoiceCallback() {

                @Override
                public void onResults(String text) {
                    statusText.setText("Processing...");
                    aiManager.send(text, JarvConfig.GEMINI_API_KEY, JarvConfig.SYSTEM_PROMPT);
                }

                @Override
                public void onError(String error) {
                    statusText.setText(error);
                }

                @Override
                public void onNoSpeechTimeout() {
                    hide();
                }
            }
    );

    voiceManager.setSilenceDetection(true);
    voiceManager.setContinuousConversation(true);
    assistantManager = new AssistantManager(voiceManager, null);

    statusText.setText("Listening...");
    assistantManager.startListening();
}

    private void startOrbAnimation() {

        micOrb.animate()
                .scaleX(1.15f)
                .scaleY(1.15f)
                .setDuration(700)
                .withEndAction(new Runnable() {

                    @Override
                    public void run() {

                        micOrb.animate()
                                .scaleX(1f)
                                .scaleY(1f)
                                .setDuration(700)
                                .withEndAction(new Runnable() {

                                    @Override
                                    public void run() {
                                        startOrbAnimation();
                                    }
                                })
                                .start();
                    }
                })
                .start();
    }
    
@Override
public void onHide() {

    super.onHide();
    voiceManager.stopSpeaking();
    voiceManager.cancelListening();
    memoryManager.clearMemory();
    }
    
@Override
public void onDestroy() {
    super.onDestroy();
    if (voiceManager != null) {
        voiceManager.cancelListening();
        voiceManager.shutdown();   // shuts down TTS engine too.
        voiceManager = null;
    }
}

}