package com.lazyjarv.assistance;

import android.content.Context;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;
import android.speech.tts.UtteranceProgressListener;
import android.content.Intent;
import android.os.Build;

public class VoiceManager {

    public interface VoiceCallback {
        void onResults(String text);
        void onError(String error);
        void onNoSpeechTimeout();
    }
    
    private Runnable noSpeechTimeout;
    private final Context context;
    private final VoiceCallback callback;
    private final Handler mainHandler;
    private TextToSpeech tts;
    private MediaRecorder recorder;
    private File audioFile;
    private final String GROQ_API_KEY = "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"; 
    private boolean isListening = false;
    private boolean useSilenceDetection = false;
    private long lastVoiceTime = 0;
    private boolean speechStarted = false;
    private static final int SILENCE_TIMEOUT = 700;
    private Runnable silenceChecker;
    private boolean continuousConversation = false;
    private int voiceFrames = 0;
    

    public VoiceManager(Context context, VoiceCallback callback) {

        this.context = context;
        this.callback = callback;
        this.mainHandler = new Handler(Looper.getMainLooper());
        
        tts = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.US);
                    
                    tts.setOnUtteranceProgressListener(
                    new UtteranceProgressListener() {

                        @Override
                        public void onStart(String utteranceId) {
                            }

                        @Override
                        public void onDone(String utteranceId) {
                            if (!continuousConversation) {
                                return;
                            }
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                startListening();
                            }
                        });
                    }

                    @Override
                        public void onError(String utteranceId) {
                    }
                });
            }
        }
    });
}
    
    public void setSilenceDetection(boolean enabled) {
        useSilenceDetection = enabled;
}

public void setContinuousConversation(boolean enabled) {
    continuousConversation = enabled;
}

public void startListening() {
    if (recorder != null) {
        try { recorder.stop();    } catch (Exception ignored) {}
        try { recorder.release(); } catch (Exception ignored) {}
        recorder = null;
    }

    // Tell the OS this process needs mic access right now
    Intent startMic = new Intent(context, MicrophoneForegroundService.class);
    startMic.setAction(MicrophoneForegroundService.ACTION_START);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(startMic);
    } else {
        context.startService(startMic);
    }
    stopSpeaking();
    isListening = true;
    
    try {

        audioFile = new File(context.getCacheDir(), "jarv_voice.m4a");

        if (audioFile.exists()) {
            audioFile.delete();
        }

        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        recorder.setOutputFile(audioFile.getAbsolutePath());

        recorder.prepare();
        recorder.start();

        if (useSilenceDetection) {

            speechStarted = false;
            lastVoiceTime = System.currentTimeMillis();
            
            noSpeechTimeout = new Runnable() {

            @Override
            public void run() {

                if (!speechStarted && isListening) {
                    cancelListening();
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            callback.onNoSpeechTimeout();
                        }
                    });
                }
            }
        };

        mainHandler.postDelayed(noSpeechTimeout, 10000);

            silenceChecker = new Runnable() {

                @Override
                public void run() {

                    if (!isListening || recorder == null) {
                        return;
                    }

                    try {

                        int amplitude = recorder.getMaxAmplitude();

                        if (amplitude > 5000) {
                            voiceFrames++;
                            if (voiceFrames >= 5) {
                                if (!speechStarted) {
                                    speechStarted = true;
                                    if (noSpeechTimeout != null) {
                                        mainHandler.removeCallbacks(noSpeechTimeout);
                                    }
                                }
                                lastVoiceTime = System.currentTimeMillis();
                            }
                        } else {
                            voiceFrames = 0;
                        }
                        
                        if (speechStarted &&
                            System.currentTimeMillis()
                            - lastVoiceTime
                            >= SILENCE_TIMEOUT) {

                           stopListening();
                           return;
                        }

                        mainHandler.postDelayed(this, 100);

                    } catch (Exception e) {
                    }
                }
            };

            mainHandler.postDelayed(silenceChecker, 100);

        }

} catch (Exception e) {
    // Do NOT throw — route the error through the callback instead
    if (recorder != null) {
        try { recorder.release(); } catch (Exception ignored) {}
        recorder = null;
    }
    isListening = false;
    // Also stop the mic service since we failed
    Intent stopMic = new Intent(context, MicrophoneForegroundService.class);
    stopMic.setAction(MicrophoneForegroundService.ACTION_STOP);
    context.startService(stopMic);
    callback.onError("Mic failed: " + e.getMessage());
}
}
        

public void stopListening() {

    isListening = false;
    if (recorder == null) {
        return;
    }

    try {
        recorder.stop();
    } catch (Exception e) {
        callback.onError(
                "Stop recorder error: "
                        + e.getMessage());

    } finally {
        try {
            recorder.release();
        } catch (Exception ignored) {
    }
        recorder = null;
    }
    sendAudioToWhisper();
}

public void cancelListening() {
    isListening = false;
    try {
        if (recorder != null) recorder.stop();
    } catch (Exception ignored) {
    } finally {
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) {}
        recorder = null;
    }
    Intent stopMic = new Intent(context, MicrophoneForegroundService.class);
    stopMic.setAction(MicrophoneForegroundService.ACTION_STOP);
    context.startService(stopMic);
}

private void sendAudioToWhisper() {
    // 1. Prevent 0-byte "Quick Tap" uploads
    if (audioFile == null || audioFile.length() < 1000) {
        sendErrorToUI("Audio too short! Please HOLD the button down.");
        return;
    }

    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                // Use a dynamic boundary for complete safety
                String boundary = "*****" + System.currentTimeMillis() + "*****";
                String LINE_FEED = "\r\n";
                String twoHyphens = "--";
                
                URL url = new URL("https://api.groq.com/openai/v1/audio/transcriptions");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setUseCaches(false);
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Authorization", "Bearer " + GROQ_API_KEY);
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

                // 2. Use pure DataOutputStream (No PrintWriter mangling)
                java.io.DataOutputStream request = new java.io.DataOutputStream(conn.getOutputStream());

                // --- Model Field ---
                request.writeBytes(twoHyphens + boundary + LINE_FEED);
                request.writeBytes("Content-Disposition: form-data; name=\"model\"" + LINE_FEED);
                request.writeBytes(LINE_FEED);
                request.writeBytes("whisper-large-v3-turbo" + LINE_FEED);

                // --- File Field ---
                request.writeBytes(twoHyphens + boundary + LINE_FEED);
                request.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" + audioFile.getName() + "\"" + LINE_FEED);
                request.writeBytes("Content-Type: audio/m4a" + LINE_FEED);
                request.writeBytes(LINE_FEED);

                // --- Raw Audio Bytes ---
                FileInputStream inputStream = new FileInputStream(audioFile);
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    request.write(buffer, 0, bytesRead);
                }
                inputStream.close();
                
                // --- End of Multipart ---
                request.writeBytes(LINE_FEED);
                request.writeBytes(twoHyphens + boundary + twoHyphens + LINE_FEED);
                request.flush();
                request.close();

                // --- Read Response ---
                int status = conn.getResponseCode();
                if (status == HttpURLConnection.HTTP_OK) {
                    java.io.InputStream responseStream = conn.getInputStream();
                    java.util.Scanner scanner = new java.util.Scanner(responseStream).useDelimiter("\\A");
                    String response = scanner.hasNext() ? scanner.next() : "";
                    
                    JSONObject json = new JSONObject(response);
                    final String transcribedText = json.getString("text");

                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            callback.onResults(transcribedText);
                        }
                    });
                } else {
                    // 3. Extract the exact JSON error from Groq
                    java.io.InputStream errorStream = conn.getErrorStream();
                    String errorResponse = "";
                    if (errorStream != null) {
                        java.util.Scanner scanner = new java.util.Scanner(errorStream).useDelimiter("\\A");
                        errorResponse = scanner.hasNext() ? scanner.next() : "";
                    }
                    sendErrorToUI("Groq Error: " + errorResponse);
                }
                conn.disconnect();
            } catch (final Exception e) {
                sendErrorToUI("Upload Error: " + e.getMessage());
            }
        }
    }).start();
}

    private void sendErrorToUI(final String msg) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                callback.onError(msg);
            }
        });
    }

    public void speak(String text) {
        if (tts != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"jarv_reply");
            } else {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            }
        }
    }

    public void shutdown() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }
    
    public boolean isListening() {
        return isListening;
    }
    
    public void stopSpeaking() {
    if (tts != null) {
        tts.stop();
    }
}
}
