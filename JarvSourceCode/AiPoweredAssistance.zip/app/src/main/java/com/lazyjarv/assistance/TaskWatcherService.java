package com.lazyjarv.assistance;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class TaskWatcherService extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        // Replicates Force Stop: clears stale native audio HAL state.
        // Android will re-bind VoiceInteractionService fresh on next trigger.
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}