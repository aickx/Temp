package com.lazyjarv.assistance;

public class AssistantManager {

    private VoiceManager voiceManager;
    private AIManager aiManager;

    public AssistantManager(
            VoiceManager voiceManager,
            AIManager aiManager) {

        this.voiceManager = voiceManager;
        this.aiManager = aiManager;
    }

    public void startListening() {

        if (voiceManager != null) {
            voiceManager.startListening();
        }
    }

    public void stopListening() {

        if (voiceManager != null) {
            voiceManager.stopListening();
        }
    }

    public void processText(String text) {

        if (aiManager != null) {

            aiManager.send(
                    text,
                    "AIzaSyBfJ55Y2gDd-Dxw9RG5LGwAdxSrltcvO3E",
                    "You are an advanced voice assistant named Lazy Jarv.");
        }
    }

    public void speak(String text) {

        if (voiceManager != null) {
            voiceManager.speak(text);
        }
    }
}