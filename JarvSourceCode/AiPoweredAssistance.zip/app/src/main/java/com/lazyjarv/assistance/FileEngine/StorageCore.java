package com.lazyjarv.assistance.FileEngine;

import android.os.Environment;
import java.io.*;

public class StorageCore {

    private final File rootDir = Environment.getExternalStorageDirectory();

    public File resolve(String p) { return new File(rootDir, p); }

    public boolean makeDirectory(String path) throws Exception {
        File dir = resolve(path);
        return dir.exists() || dir.mkdirs();
    }

    public void createNewFile(String path, String content) throws Exception {
        File file = resolve(path);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileWriter fw = new FileWriter(file)) { fw.write(content); fw.flush(); }
    }

    public boolean deletePath(String path) throws Exception {
        File f = resolve(path);
        if (!f.exists()) return false;
        if (f.isDirectory()) { deleteRecursive(f); return true; }
        return f.delete();
    }

    private void deleteRecursive(File f) {
        if (f.isDirectory()) { File[] ch = f.listFiles(); if (ch != null) for (File c : ch) deleteRecursive(c); }
        f.delete();
    }

    public void copyPath(String src, String dst) throws Exception {
        File s = resolve(src), d = resolve(dst);
        if (!s.exists()) throw new FileNotFoundException("Source missing: " + src);
        if (s.isDirectory()) copyDirRecursive(s, d); else copyFileSingle(s, d);
    }

    public void copyFileSingle(File src, File dst) throws Exception {
        File p = dst.getParentFile(); if (p != null && !p.exists()) p.mkdirs();
        try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[4096]; int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
        }
    }

    private void copyDirRecursive(File src, File dst) throws Exception {
        if (!dst.exists()) dst.mkdirs();
        String[] ch = src.list();
        if (ch != null) for (String c : ch) copyDirRecursive(new File(src, c), new File(dst, c));
    }

    public void movePath(String src, String dst) throws Exception {
        File s = resolve(src), d = resolve(dst);
        if (!s.exists()) throw new FileNotFoundException("Source missing: " + src);
        File p = d.getParentFile(); if (p != null && !p.exists()) p.mkdirs();
        if (!s.renameTo(d)) { copyPath(src, dst); deletePath(src); }
    }

    public String readTextPath(String path) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(resolve(path)))) {
            String line; while ((line = br.readLine()) != null) sb.append(line).append("\n");
        }
        return sb.toString().trim();
    }

    public long getFileSystemSize(String path) throws Exception {
        File f = resolve(path);
        return f.isFile() ? f.length() : getFolderSizeRecursive(f);
    }

    private long getFolderSizeRecursive(File folder) {
        long size = 0; File[] files = folder.listFiles();
        if (files != null) for (File f : files) size += f.isFile() ? f.length() : getFolderSizeRecursive(f);
        return size;
    }
}