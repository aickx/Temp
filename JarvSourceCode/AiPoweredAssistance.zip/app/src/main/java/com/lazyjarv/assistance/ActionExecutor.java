package com.lazyjarv.assistance;

import android.app.SearchManager;
import android.content.*;
import android.net.Uri;
import android.provider.AlarmClock;
import android.content.pm.*;
import org.json.JSONObject;
import java.util.List;

public class ActionExecutor {

    private final Context context;
    private final AppManager appManager;

    public ActionExecutor(Context context, AppManager appManager) {
        this.context = context;
        this.appManager = appManager;
    }

    public void execute(final JSONObject liveReply) {

        try {

            String action =
                    liveReply.optString("action", "");

            switch (action) {

                case "set_alarm": {

                    int hour =
                            liveReply.optInt("time_value", 0);

                    int minute =
                            liveReply.optInt("time_minute", 0);

                    Intent i =
                            new Intent(
                                    AlarmClock.ACTION_SET_ALARM);

                    i.putExtra(
                            AlarmClock.EXTRA_HOUR,
                            hour);

                    i.putExtra(
                            AlarmClock.EXTRA_MINUTES,
                            minute);

                    i.putExtra(
                            AlarmClock.EXTRA_MESSAGE,
                            "Lazy Jarv Alarm");

                    i.putExtra(
                            AlarmClock.EXTRA_SKIP_UI,
                            true);

                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    context.startActivity(i);

                    break;
                }

                case "set_timer": {

                    int secs =
                            liveReply.optInt("time_value", 0);

                    Intent i =
                            new Intent(
                                    AlarmClock.ACTION_SET_TIMER);

                    i.putExtra(
                            AlarmClock.EXTRA_LENGTH,
                            secs);

                    i.putExtra(
                            AlarmClock.EXTRA_MESSAGE,
                            "Lazy Jarv Timer");

                    i.putExtra(
                            AlarmClock.EXTRA_SKIP_UI,
                            true);

                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    context.startActivity(i);

                    break;
                }

                case "open_stopwatch": {

                    Intent i =
                            new Intent(
                                    AlarmClock.ACTION_SHOW_ALARMS);

                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    context.startActivity(i);

                    break;
                }

                case "open_app": {

                    String target =
                            liveReply.optString("target", "")
                                    .toLowerCase()
                                    .trim();

                    if (target.contains("dialer")
                            || target.contains("phone")
                            || target.contains("call")) {

                        Intent i =
                                new Intent(Intent.ACTION_DIAL);

                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                        context.startActivity(i);

                    } else if (!target.isEmpty()) {

                        String pkg =
                                appManager.findPackage(target);

                        if (!pkg.isEmpty()) {

                            Intent launch =
                                    context.getPackageManager()
                                            .getLaunchIntentForPackage(pkg);

                            if (launch != null) {

                                launch.addFlags(
                                        Intent.FLAG_ACTIVITY_NEW_TASK);

                                context.startActivity(launch);
                            }

                        } else {

                            openPlayStore(target);
                        }
                    }

                    break;
                }

                case "ask_download":
                case "confirm_download": {

                    String target =
                            liveReply.optString("target", "");

                    if (!target.isEmpty()) {

                        openPlayStore(target);
                    }

                    break;
                }

                case "search_app": {

                    String target =
                            liveReply.optString("target", "")
                                    .toLowerCase();

                    String query =
                            liveReply.optString("query", "");

                    Intent i;

                    if (target.contains("youtube")) {

                        i = new Intent(Intent.ACTION_VIEW);

                        i.setData(
                                Uri.parse(
                                        "https://www.youtube.com/results?search_query="
                                                + java.net.URLEncoder.encode(
                                                query,
                                                "UTF-8")));

                        i.setPackage("com.google.android.youtube");

                    } else {

                        i = new Intent(Intent.ACTION_WEB_SEARCH);

                        i.putExtra(
                                SearchManager.QUERY,
                                query);
                    }

                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    context.startActivity(i);

                    break;
                }

                case "create_note":
                case "save_txt_file": {

                    String content =
                            liveReply.optString("content", "");

                    if (!content.trim().isEmpty()
                            && !content.equalsIgnoreCase("none")
                            && !content.equalsIgnoreCase("null")) {

                        saveNote(content);
                    }

                    break;
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public void openPlayStore(String appName) {

        try {

            Intent i =
                    new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(
                                    "market://search?q="
                                            + java.net.URLEncoder.encode(
                                            appName,
                                            "UTF-8")));

            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            context.startActivity(i);

        } catch (Exception e) {

            try {

                Intent i =
                        new Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse(
                                        "https://play.google.com/store/search?q="
                                                + java.net.URLEncoder.encode(
                                                appName,
                                                "UTF-8")));

                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                context.startActivity(i);

            } catch (Exception ignored) {
            }
        }
    }

    public void saveNote(String content) {

        if (content == null
                || content.trim().isEmpty()) {

            return;
        }

        try {

            Intent noteIntent =
                    new Intent(Intent.ACTION_SEND);

            noteIntent.setType("text/plain");

            noteIntent.putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Lazy Jarv Note");

            noteIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    content);

            PackageManager pm =
                    context.getPackageManager();

            List<ResolveInfo> matches =
                    pm.queryIntentActivities(
                            noteIntent,
                            0);

            String notePkg = "";

            for (ResolveInfo info : matches) {

                String pkg =
                        info.activityInfo.packageName
                                .toLowerCase();

                String label =
                        info.loadLabel(pm)
                                .toString()
                                .toLowerCase();

                if (pkg.contains("notes")
                        || pkg.contains("memo")
                        || pkg.contains("keep")
                        || label.contains("note")
                        || label.contains("memo")
                        || label.contains("keep")) {

                    notePkg =
                            info.activityInfo.packageName;

                    break;
                }
            }

            if (!notePkg.isEmpty()) {

                noteIntent.setPackage(notePkg);
            }

            noteIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            context.startActivity(noteIntent);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}