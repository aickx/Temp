package com.lazyjarv.assistance.FileEngine;

import android.os.Environment;
import java.io.*;

public class CryptoManager {

    private final File rootDir = Environment.getExternalStorageDirectory();

    private File resolve(String p) { return new File(rootDir, p); }

    public void processCryptoPath(String src, String dst, boolean encrypt) throws Exception {
        File s = resolve(src), d = resolve(dst);
        File p = d.getParentFile(); if (p != null && !p.exists()) p.mkdirs();
        try (FileInputStream fis = new FileInputStream(s); FileOutputStream fos = new FileOutputStream(d)) {
            byte[] buf = new byte[4096]; int len; byte key = 0x5A;
            while ((len = fis.read(buf)) != -1) {
                for (int i = 0; i < len; i++) buf[i] ^= key;
                fos.write(buf, 0, len);
            }
        }
    }

    public void shredPath(String path) throws Exception {
        File f = resolve(path);
        if (f.isFile()) shredFile(f);
        else if (f.isDirectory()) shredDirRecursive(f);
    }

    private void shredFile(File f) throws Exception {
        long len = f.length();
        try (RandomAccessFile raf = new RandomAccessFile(f, "rws")) {
            byte[] zeros = new byte[4096]; long written = 0;
            while (written < len) { int w = (int) Math.min(zeros.length, len - written); raf.write(zeros, 0, w); written += w; }
        }
        f.delete();
    }

    private void shredDirRecursive(File dir) throws Exception {
        File[] ch = dir.listFiles();
        if (ch != null) for (File c : ch) { if (c.isDirectory()) shredDirRecursive(c); else shredFile(c); }
        dir.delete();
    }
}