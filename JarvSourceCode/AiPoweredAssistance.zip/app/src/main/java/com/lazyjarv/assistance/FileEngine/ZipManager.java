package com.lazyjarv.assistance.FileEngine;

import android.os.Environment;
import java.io.*;
import java.util.zip.*;

public class ZipManager {

    private final File rootDir = Environment.getExternalStorageDirectory();

    private File resolve(String p) { return new File(rootDir, p); }

    public void zipPath(String src, String dstZip) throws Exception {
        File source = resolve(src), zip = resolve(dstZip);
        File p = zip.getParentFile(); if (p != null && !p.exists()) p.mkdirs();
        try (FileOutputStream fos = new FileOutputStream(zip);
             ZipOutputStream zos = new ZipOutputStream(fos)) {
            zipRecursive(source, source.getName(), zos);
        }
    }

    private void zipRecursive(File f, String name, ZipOutputStream zos) throws Exception {
        if (f.isHidden()) return;
        if (f.isDirectory()) {
            zos.putNextEntry(new ZipEntry(name.endsWith("/") ? name : name + "/"));
            zos.closeEntry();
            File[] ch = f.listFiles();
            if (ch != null) for (File c : ch) zipRecursive(c, name + "/" + c.getName(), zos);
            return;
        }
        try (FileInputStream fis = new FileInputStream(f)) {
            zos.putNextEntry(new ZipEntry(name));
            byte[] buf = new byte[4096]; int len;
            while ((len = fis.read(buf)) >= 0) zos.write(buf, 0, len);
        }
    }

    public void unzipPath(String srcZip, String dstDir) throws Exception {
        File dest = resolve(dstDir); if (!dest.exists()) dest.mkdirs();
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(resolve(srcZip)))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                File out = new File(dest, entry.getName());
                if (entry.isDirectory()) { out.mkdirs(); }
                else {
                    File par = out.getParentFile(); if (par != null && !par.exists()) par.mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        byte[] buf = new byte[4096]; int len;
                        while ((len = zis.read(buf)) > 0) fos.write(buf, 0, len);
                    }
                }
                zis.closeEntry();
            }
        }
    }
}