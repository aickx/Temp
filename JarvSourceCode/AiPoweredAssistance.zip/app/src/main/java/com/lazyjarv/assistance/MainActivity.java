package com.lazyjarv.assistance;

import android.view.MotionEvent;
import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.View;
import org.json.JSONObject;
import com.lazyjarv.assistance.JarvConfig;

public class MainActivity extends Activity implements AIManager.AICallback, FileManager.FileCallback {

    private MainBinding binding;
    private String api_key = "";
    private String system_prompt = "";
    private String user_input = "";
    private boolean includeAppsOnce = false;

    private VoiceManager voiceManager;
    private AppManager appManager;
    private MemoryManager memoryManager;
    private AIManager aiManager;
    private ActionExecutor actionExecutor;
    private FileManager fileManager;
    private AssistantManager assistantManager;
    
    private android.media.AudioManager audioManager;

    private FileManager.ConfirmationCallback pendingConfirmation;

    private VoiceManager.VoiceCallback normalVoiceCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startService(new Intent(this, TaskWatcherService.class));
        binding = MainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize();

        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_DENIED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1000);
            } else { 
                initializeLogic(); 
            }
        } else { 
            initializeLogic(); 
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1000) initializeLogic();
    }

    private void initialize() {
        appManager    = new AppManager();
        memoryManager = new MemoryManager();
        fileManager   = new FileManager(this, this);
        actionExecutor = new ActionExecutor(this, appManager);
        aiManager     = new AIManager(this, this, memoryManager);
        
        audioManager = (android.media.AudioManager) getSystemService(Context.AUDIO_SERVICE);

        normalVoiceCallback = new VoiceManager.VoiceCallback() {
            @Override
            public void onResults(String result) {
                if (pendingConfirmation != null) {
                    boolean yes = result != null && (result.toLowerCase().contains("yes") || result.toLowerCase().contains("confirm"));
                    if (!yes && result != null && !result.toLowerCase().contains("no") && !result.toLowerCase().contains("cancel")) {
                        voiceManager.speak("Please say yes or no.");
                        return;
                    }
                    pendingConfirmation.onConfirmed(yes);
                    pendingConfirmation = null;
                    return;
                }
                user_input = result;
                binding.tvStatus.setText(result);
                aiManager.send(user_input, api_key, system_prompt);
            }

            @Override
            public void onError(String errorMsg) {
                if (pendingConfirmation != null) {
                    pendingConfirmation.onConfirmed(false);
                    pendingConfirmation = null;
                }
                binding.tvStatus.setText("Voice Error: " + errorMsg);
            }
            
            @Override
            public void onNoSpeechTimeout() {
            }
        };


        voiceManager = new VoiceManager(getApplicationContext(), normalVoiceCallback); 
        voiceManager.setSilenceDetection(false);
        voiceManager.setContinuousConversation(false); // <==================== Voice manager Boolens ================≠=========
        
        
        assistantManager = new AssistantManager(voiceManager,aiManager);

        binding.btnMic.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        playJarvChime(R.raw.onhold);
                        assistantManager.startListening();
                        binding.tvStatus.setText("Listening...");
                        return true;

                    case MotionEvent.ACTION_UP:
                        playJarvChime(R.raw.onrelease);
                        assistantManager.stopListening();
                        binding.tvStatus.setText("Processing voice...");
                        return true;
                }
                return false;
            }
        });
                // Hook for launching system assistant setup screen
        binding.btnMic.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                openAssistantSettings();
                return true;
            }
        });

    }

    private void initializeLogic() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.view.Window window = getWindow();
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#050505"));
        }

        GradientDrawable topGlow = new GradientDrawable();
        topGlow.setColor(Color.TRANSPARENT);
        topGlow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        topGlow.setGradientRadius(900f);
        topGlow.setGradientCenter(0.5f, -0.4f);
        topGlow.setColors(new int[]{Color.parseColor("#B6A7F1"), Color.parseColor("#00000000")});

        GradientDrawable purpleHorizonA = new GradientDrawable();
        purpleHorizonA.setColor(Color.TRANSPARENT);
        purpleHorizonA.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        purpleHorizonA.setGradientRadius(1100f);
        purpleHorizonA.setGradientCenter(0.5f, 1.2f);
        purpleHorizonA.setColors(new int[]{Color.parseColor("#7444DE"), Color.parseColor("#00000000")});

        GradientDrawable purpleHorizonB = new GradientDrawable();
        purpleHorizonB.setColor(Color.TRANSPARENT);
        purpleHorizonB.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        purpleHorizonB.setGradientRadius(1000f);
        purpleHorizonB.setGradientCenter(0.5f, 1.2f);
        purpleHorizonB.setColors(new int[]{Color.parseColor("#7444DE"), Color.parseColor("#00000000")});

        GradientDrawable blackMask = new GradientDrawable();
        blackMask.setColor(Color.TRANSPARENT);
        blackMask.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        blackMask.setGradientRadius(1000f);
        blackMask.setGradientCenter(0.5f, 0.78f);
        blackMask.setColors(new int[]{Color.parseColor("#050505"), Color.parseColor("#00050505")});

        ColorDrawable solidBlackBase = new ColorDrawable(Color.parseColor("#050505"));
        Drawable[] layerStack = {solidBlackBase, purpleHorizonA, purpleHorizonB, topGlow, blackMask};
        binding.linear1.setBackground(new LayerDrawable(layerStack));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().getDecorView().setSystemUiVisibility(
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.parseColor("#050505"));
        }

        GradientDrawable roundedButton = new GradientDrawable();
        roundedButton.setColor(Color.parseColor("#12FFFFFF"));
        roundedButton.setShape(GradientDrawable.RECTANGLE);    
        roundedButton.setCornerRadius(100f);
        roundedButton.setStroke(4, Color.parseColor("#12FFFFFF"));

        binding.btnMic.setBackground(roundedButton);
        binding.btnMic.setText("");

        float scale = getResources().getDisplayMetrics().density;
        int heightPx = (int) (65 * scale + 0.5f);
        int sideMarginPx = (int) (16 * scale + 0.5f);
        int bottomMarginPx = (int) (20 * scale + 0.5f);

        if (binding.btnMic.getLayoutParams() instanceof android.view.ViewGroup.MarginLayoutParams) {
            android.view.ViewGroup.MarginLayoutParams params = 
                (android.view.ViewGroup.MarginLayoutParams) binding.btnMic.getLayoutParams();
            
            params.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;
            params.height = heightPx;
            params.setMargins(sideMarginPx, params.topMargin, sideMarginPx, bottomMarginPx);
            binding.btnMic.setLayoutParams(params);
        }

        if (Build.VERSION.SDK_INT >= 21) {
            binding.btnMic.setElevation(15f);
        }

        binding.imgJarv.setAlpha(0.85f);

        api_key = JarvConfig.GEMINI_API_KEY;

        system_prompt = JarvConfig.SYSTEM_PROMPT;
        appManager.loadApps(getApplicationContext());
    }

    @Override
    public void onSpeechReady(String speech) {
        binding.tvStatus.setText(speech);
        voiceManager.speak(speech);
    }

    @Override
    public void onActionReady(JSONObject liveReply) {
        try {
            if ("file_op".equals(liveReply.optString("action", ""))) {
                fileManager.processFileEngine(liveReply);
            } else {
                actionExecutor.execute(liveReply);
            }
        } catch (Exception e) {}
    }

    @Override public void onError(String message) { SketchwareUtil.showMessage(getApplicationContext(), message); }
    @Override public String getAppData() { return appManager.getAppData(); }
    @Override public boolean shouldIncludeApps() { return includeAppsOnce; }
    @Override public void setIncludeApps(boolean value) { includeAppsOnce = value; }
    @Override public void onNeedAppList(String userInput) { aiManager.send(userInput, api_key, system_prompt); }

    @Override
    public void updateStatus(final String message) {
        runOnUiThread(new Runnable() { @Override public void run() { binding.tvStatus.setText(message); } });
    }

    @Override
    public void speak(final String message) {
        runOnUiThread(new Runnable() { @Override public void run() { voiceManager.speak(message); } });
    }

    @Override public void showToast(String message) { SketchwareUtil.showMessage(getApplicationContext(), message); }
    @Override public Activity getActivity() { return this; }

    @Override
    public void requestConfirmation(final String message, final FileManager.ConfirmationCallback cb) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                voiceManager.speak(message);
                pendingConfirmation = cb;
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!voiceManager.isListening()) {
                            voiceManager.startListening();
                            binding.tvStatus.setText("Please say yes or no");
                        }
                    }
                }, 2000); 
            }
        });
    }
    
    private void playJarvChime(int soundResource) {
        android.media.MediaPlayer player = android.media.MediaPlayer.create(MainActivity.this, soundResource);
        if (player != null) {
            player.start();
            player.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(android.media.MediaPlayer mp) {
                    mp.release(); 
                }
            });
        }
    }

    private void setJarvMuteState(boolean mute) {
        audioManager.setStreamMute(android.media.AudioManager.STREAM_MUSIC, mute);
        audioManager.setStreamMute(android.media.AudioManager.STREAM_SYSTEM, mute);
        audioManager.setStreamMute(android.media.AudioManager.STREAM_NOTIFICATION, mute);
        audioManager.setStreamMute(android.media.AudioManager.STREAM_ALARM, mute);
        audioManager.setStreamMute(android.media.AudioManager.STREAM_RING, mute);
    }
        @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Check if app was brought to foreground via default assistant trigger
        if (getIntent().getBooleanExtra("voice_trigger", false)) {
            getIntent().removeExtra("voice_trigger");
            playJarvChime(R.raw.onhold);
            voiceManager.startListening();
            binding.tvStatus.setText("Listening...");
        }
    }

    public void openAssistantSettings() {
        try {
            Intent intent = new Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            showToast("Error opening settings: " + e.getMessage());
        }
    }
    
@Override
protected void onDestroy() {
    super.onDestroy();
    voiceManager.stopSpeaking();
    voiceManager.cancelListening();
    }
}
