package com.lazyjarv.assistance.FileEngine;

import android.os.Environment;
import java.io.File;
import com.lazyjarv.assistance.Utils;

public class SearchManager {

    private final File rootDir = Environment.getExternalStorageDirectory();
    private String bestMatchPath = null;
    private int bestMatchScore = 4;

    public String locateFile(String targetName) {
        bestMatchPath = null; bestMatchScore = 4;
        searchDirFuzzy(rootDir, targetName.toLowerCase().trim());
        return bestMatchPath;
    }

    private void searchDirFuzzy(File dir, String target) {
        File[] files = dir.listFiles(); if (files == null) return;
        for (File f : files) {
            String name = f.getName().toLowerCase();
            if (name.contains(target)) {
                bestMatchPath = f.getAbsolutePath(); bestMatchScore = 0;
                if (name.equals(target)) return;
            }
            if (bestMatchScore > 0) {
                int d = Utils.getFuzzyDistance(target, name);
                if (d < bestMatchScore) { bestMatchScore = d; bestMatchPath = f.getAbsolutePath(); }
            }
            if (f.isDirectory()) searchDirFuzzy(f, target);
        }
    }
}