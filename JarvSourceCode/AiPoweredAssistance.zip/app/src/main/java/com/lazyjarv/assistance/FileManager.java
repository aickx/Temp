package com.lazyjarv.assistance;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.concurrent.CountDownLatch;

import com.lazyjarv.assistance.FileEngine.AggregateManager;
import com.lazyjarv.assistance.FileEngine.CryptoManager;
import com.lazyjarv.assistance.FileEngine.FileValidator;
import com.lazyjarv.assistance.FileEngine.SearchManager;
import com.lazyjarv.assistance.FileEngine.StorageCore;
import com.lazyjarv.assistance.FileEngine.ZipManager;

public class FileManager {

    /**
     * Callback used by FileManager to communicate with the UI / voice layer.
     * FIX #2: Added requestConfirmation for touch-less voice confirmations.
     */
    public interface FileCallback {
        void updateStatus(String message);
        void speak(String message);
        void showToast(String message);
        Activity getActivity();
        /**
         * Ask the user a yes/no question via TTS and return the answer through the callback.
         * The implementation should speak the message, listen for voice input,
         * and call {@code cb.onConfirmed(true/false)} once the answer is recognised.
         */
        void requestConfirmation(String message, ConfirmationCallback cb);
    }

    /**
     * Callback for touch-less confirmation (FIX #2).
     */
    public interface ConfirmationCallback {
        void onConfirmed(boolean confirmed);
    }

    private final Activity activity;
    private final FileCallback callback;

    private final StorageCore storageCore;
    private final ZipManager zipManager;
    private final CryptoManager cryptoManager;
    private final SearchManager searchManager;
    private final AggregateManager aggregateManager;

    // FIX #2 – track files created by Jarv in the current session
    private final Set<String> createdThisSession = new HashSet<>();

    // FIX #1 – store pending task when permission is missing
    private JSONObject pendingTask = null;

    // Root directory for safety checks (FIX #5)
    private final File rootDir = Environment.getExternalStorageDirectory();

    public FileManager(Activity activity, FileCallback callback) {
        this.activity = activity;
        this.callback = callback;
        this.storageCore    = new StorageCore();
        this.zipManager     = new ZipManager();
        this.cryptoManager  = new CryptoManager();
        this.searchManager  = new SearchManager();
        final FileCallback fileCallback = callback;
        this.aggregateManager = new AggregateManager(activity, storageCore,
            new AggregateManager.ProgressCallback() {
                @Override public void onProgress(String message) { fileCallback.updateStatus(message); }
            });
    }

    // ==========================================
    // DATA MODELS (unchanged)
    // ==========================================
    public static class FileOpNode {
        public int id;
        public String op, src, dst, content, cond;
        public List<Integer> dep = new ArrayList<>();
        public String status = "PENDING";
        public String failureReason = "";

        public FileOpNode(JSONObject obj) {
            this.id = obj.optInt("id", 0);
            this.op = obj.optString("op", "");
            this.src = obj.optString("src", "");
            this.dst = obj.optString("dst", "");
            this.content = obj.optString("content", "");
            this.cond = obj.optString("cond", "none");
            JSONArray depArr = obj.optJSONArray("dep");
            if (depArr != null)
                for (int i = 0; i < depArr.length(); i++) dep.add(depArr.optInt(i));
        }
    }

    public static class ExecutionReport {
        public int totalOps = 0;
        public List<String> succeeded = new ArrayList<>();
        public List<String> failed = new ArrayList<>();
        public List<String> skipped = new ArrayList<>();

        public String buildSummaryString() {
            return "Task finished. Succeeded: " + succeeded.size() +
                ", Failed: " + failed.size() + ", Skipped: " + skipped.size();
        }
    }

    // ==========================================
    // PUBLIC ENTRY POINT (FIX #1, #5)
    // ==========================================
    public void processFileEngine(final JSONObject liveReply) {
        // FIX #1 – Permission check first, before any TTS output
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            // Store the task for later retry
            pendingTask = liveReply;
            activity.runOnUiThread(new Runnable() {
                @Override public void run() {
                    callback.speak("I need storage access to perform file operations. Please grant the permission.");
                    callback.updateStatus("Requesting storage permission…");
                    try {
                        Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                        intent.setData(android.net.Uri.parse("package:" + activity.getPackageName()));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        activity.startActivity(intent);
                    } catch (Exception e) {
                        Intent fb = new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                        fb.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        activity.startActivity(fb);
                    }
                }
            });
            return; // Will be retried when permission is granted
        }

        // Normal flow with permission already granted
        executeTasks(liveReply);
    }

    /**
     * Call this from your Activity's onActivityResult (or similar) once the user
     * has granted the storage permission. It will re-run the last requested task.
     * FIX #1
     */
    public void retryAfterPermissionGranted() {
        if (pendingTask != null) {
            JSONObject task = pendingTask;
            pendingTask = null;
            executeTasks(task);
        }
    }

    /**
     * Core execution logic (moved here for reuse after permission grant).
     */
    private void executeTasks(final JSONObject liveReply) {
        try {
            JSONArray tasksArray = liveReply.optJSONArray("file_tasks");
            if (tasksArray == null || tasksArray.length() == 0) return;

            final List<FileOpNode> allNodes = new ArrayList<>();
            final Map<Integer, FileOpNode> nodeMap = new HashMap<>();
            for (int i = 0; i < tasksArray.length(); i++) {
                JSONObject obj = tasksArray.optJSONObject(i);
                if (obj != null) { FileOpNode n = new FileOpNode(obj); allNodes.add(n); nodeMap.put(n.id, n); }
            }

            // Pre-process aggregate→size chains into count ops (unchanged)
            {
                Map<String, FileOpNode> aggByDst = new HashMap<>();
                for (FileOpNode n : allNodes)
                    if ("aggregate".equals(n.op) && n.dst != null && !n.dst.isEmpty())
                        aggByDst.put(n.dst.toLowerCase().trim(), n);
                for (FileOpNode sizeNode : allNodes) {
                    if (!"size".equals(sizeNode.op)) continue;
                    String sizeSrc = sizeNode.src == null ? "" : sizeNode.src.toLowerCase().trim();
                    FileOpNode aggNode = aggByDst.get(sizeSrc);
                    if (aggNode != null) { aggNode.op = "count"; aggNode.dst = ""; sizeNode.op = "count_skip"; sizeNode.src = ""; }
                    else if (sizeSrc.matches("^\\.?[a-z0-9]{2,5}$")) { sizeNode.op = "count"; sizeNode.src = sizeSrc.startsWith(".") ? sizeSrc : "." + sizeSrc; }
                }
            }

            // Topological sort (unchanged)
            Map<Integer, List<Integer>> adj = new HashMap<>();
            Map<Integer, Integer> inDeg = new HashMap<>();
            for (FileOpNode n : allNodes) { inDeg.put(n.id, 0); adj.put(n.id, new ArrayList<Integer>()); }
            for (FileOpNode n : allNodes) for (int dep : n.dep) { if (adj.containsKey(dep)) { adj.get(dep).add(n.id); inDeg.put(n.id, inDeg.get(n.id) + 1); } }

            Queue<Integer> queue = new LinkedList<>();
            for (FileOpNode n : allNodes) if (inDeg.get(n.id) == 0) queue.add(n.id);
            final List<FileOpNode> sorted = new ArrayList<>();
            while (!queue.isEmpty()) {
                int id = queue.poll(); FileOpNode cur = nodeMap.get(id);
                if (cur != null) sorted.add(cur);
                List<Integer> neighbors = adj.get(id);
                if (neighbors != null) for (int nb : neighbors) { inDeg.put(nb, inDeg.get(nb) - 1); if (inDeg.get(nb) == 0) queue.add(nb); }
            }

            if (sorted.size() != allNodes.size()) { callback.showToast("Cyclic dependency detected!"); return; }

            new Thread(new Runnable() {
                @Override public void run() {
                    ExecutionReport report = new ExecutionReport();
                    report.totalOps = sorted.size();

                    nodeLoop:
                    for (final FileOpNode node : sorted) {
                        boolean depFailed = false;
                        for (int dep : node.dep) { FileOpNode p = nodeMap.get(dep); if (p != null && !p.status.equals("SUCCESS")) { depFailed = true; break; } }
                        if (depFailed) { node.status = "SKIPPED"; report.skipped.add("Task " + node.id); continue; }

                        // Apply fuzzy resolution cache (unchanged)
                        if (node.src != null && !node.src.isEmpty()) {
                            int ls = node.src.lastIndexOf('/');
                            String base = ls >= 0 ? node.src.substring(ls + 1) : node.src;
                            String dir  = ls >= 0 ? node.src.substring(0, ls + 1) : "";
                            String corr = FileValidator.fuzzyResolutionCache.get(base.toLowerCase());
                            if (corr != null) { node.src = dir + corr; FileValidator.fuzzyResolutionCache.remove(base.toLowerCase()); }
                        }

                        activity.runOnUiThread(new Runnable() {
                            @Override public void run() { callback.updateStatus("Executing: " + node.op + " on " + node.src); }
                        });

                        node.status = "RUNNING";
                        try {
                            File rawFile = storageCore.resolve(node.src);
                            boolean isCreate = node.op.equals("mkdir") || node.op.equals("create");

                            // FIX #5 – Restrict access to system files
                            if (!isCreate && !node.op.equals("aggregate") && !node.op.equals("count") && !node.op.equals("count_skip")) {
                                if (!isSafePath(rawFile)) {
                                    throw new SecurityException("I cannot access system files for security reasons. Only files in your regular storage are accessible.");
                                }
                            }

                            if (!isCreate && !node.op.equals("aggregate") && !node.op.equals("count") && !node.op.equals("count_skip") && !rawFile.exists()) {
                                String suggestion = FileValidator.checkAndSuggest(rawFile);
                                throw new FileNotFoundException("File not found: " + node.src + "." + suggestion);
                            }

                            if (node.cond.equals("if_not_exists") && rawFile.exists()) {
                                node.status = "SUCCESS"; report.succeeded.add(node.op + ": " + node.src + " (Skipped: Exists)"); continue;
                            }

                            switch (node.op) {
                                case "mkdir": {
                                    storageCore.makeDirectory(node.src);
                                    // FIX #2 – remember created directory
                                    createdThisSession.add(rawFile.getAbsolutePath());
                                    break;
                                }
                                case "create": {
                                    storageCore.createNewFile(node.src, node.content);
                                    // FIX #2 – remember created file
                                    createdThisSession.add(rawFile.getAbsolutePath());
                                    break;
                                }
                                case "delete": {
                                    // FIX #2 – voice confirmation unless created this session
                                    if (!createdThisSession.contains(rawFile.getAbsolutePath())) {
                                        final CountDownLatch deleteLatch = new CountDownLatch(1);
                                        final boolean[] deleteConfirmed = {false};
                                        activity.runOnUiThread(new Runnable() {
                                            @Override public void run() {
                                                callback.requestConfirmation("Are you sure you want to delete " + node.src + "?",
                                                    new ConfirmationCallback() {
                                                        @Override public void onConfirmed(boolean confirmed) {
                                                            deleteConfirmed[0] = confirmed;
                                                            deleteLatch.countDown();
                                                        }
                                                    });
                                            }
                                        });
                                        try { deleteLatch.await(); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                                        if (!deleteConfirmed[0]) {
                                            node.status = "SKIPPED"; report.skipped.add("delete: " + node.src + " (Cancelled)");
                                            activity.runOnUiThread(new Runnable() {
                                                @Override public void run() { callback.updateStatus("Deletion cancelled."); callback.speak("Deletion cancelled."); }
                                            });
                                            continue nodeLoop;
                                        }
                                    }
                                    storageCore.deletePath(node.src);
                                    // Remove from session set if it was there (just in case)
                                    createdThisSession.remove(rawFile.getAbsolutePath());
                                    break;
                                }
                                case "copy":              storageCore.copyPath(node.src, node.dst); break;
                                case "move": case "rename": storageCore.movePath(node.src, node.dst); break;
                                case "zip":               zipManager.zipPath(node.src, node.dst); break;
                                case "unzip":             zipManager.unzipPath(node.src, node.dst); break;
                                case "shred": {
                                    // FIX #2 – voice confirmation, same rules as delete
                                    if (!createdThisSession.contains(rawFile.getAbsolutePath())) {
                                        final CountDownLatch shredLatch = new CountDownLatch(1);
                                        final boolean[] shredConfirmed = {false};
                                        activity.runOnUiThread(new Runnable() {
                                            @Override public void run() {
                                                callback.requestConfirmation("Permanently shred " + node.src + "? This cannot be undone.",
                                                    new ConfirmationCallback() {
                                                        @Override public void onConfirmed(boolean confirmed) {
                                                            shredConfirmed[0] = confirmed;
                                                            shredLatch.countDown();
                                                        }
                                                    });
                                            }
                                        });
                                        try { shredLatch.await(); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                                        if (!shredConfirmed[0]) {
                                            node.status = "SKIPPED"; report.skipped.add("shred: " + node.src + " (Cancelled)");
                                            activity.runOnUiThread(new Runnable() {
                                                @Override public void run() { callback.updateStatus("Shred cancelled."); callback.speak("Shred cancelled."); }
                                            });
                                            continue nodeLoop;
                                        }
                                    }
                                    cryptoManager.shredPath(node.src);
                                    createdThisSession.remove(rawFile.getAbsolutePath());
                                    break;
                                }
                                case "encrypt": cryptoManager.processCryptoPath(node.src, node.dst, true);  break;
                                case "decrypt": cryptoManager.processCryptoPath(node.src, node.dst, false); break;
                                case "read": {
                                    final String text = storageCore.readTextPath(node.src);
                                    activity.runOnUiThread(new Runnable() { @Override public void run() { callback.updateStatus("Read:\n" + text); callback.speak("File read successfully."); } });
                                    break;
                                }
                                case "size": {
                                    String sn = node.src == null ? "" : node.src.trim();
                                    if (sn.matches("^\\.?[a-zA-Z0-9]{2,5}$")) {
                                        if (!sn.startsWith(".")) sn = "." + sn;
                                        long[] cnt = aggregateManager.countFiles(sn);
                                        final long c = cnt[0]; final String extLabel = sn.substring(1).toUpperCase(), sz = Utils.formatFileSize(cnt[1]);
                                        activity.runOnUiThread(new Runnable() { @Override public void run() {
                                            String msg;
                                            // FIX #3 – friendly message when no files found
                                            if (c == 0) {
                                                msg = "No " + extLabel + " files found on your device. You might want to use a downloader or browser to get some.";
                                            } else {
                                                msg = "There are " + c + " " + extLabel + " files (" + sz + " total)";
                                            }
                                            callback.updateStatus(msg);
                                            callback.speak(msg);
                                        }});
                                    } else {
                                        final long bytes = storageCore.getFileSystemSize(node.src);
                                        final String fs = Utils.formatFileSize(bytes);
                                        activity.runOnUiThread(new Runnable() { @Override public void run() { callback.updateStatus("Size: " + fs); callback.speak("The size is " + fs + "."); } });
                                    }
                                    break;
                                }
                                case "count_skip": break;
                                case "aggregate": {
                                    if (node.dst == null || node.dst.trim().isEmpty()) {
                                        long[] cnt = aggregateManager.countFiles(node.src);
                                        final long c = cnt[0];
                                        final String extLabel = node.src.startsWith(".") ? node.src.substring(1).toUpperCase() : node.src.toUpperCase();
                                        final String sz = Utils.formatFileSize(cnt[1]);
                                        activity.runOnUiThread(new Runnable() { @Override public void run() {
                                            String msg;
                                            if (c == 0) {
                                                msg = "No " + extLabel + " files found. Consider downloading some first.";
                                            } else {
                                                msg = "There are " + c + " " + extLabel + " files (" + sz + " total)";
                                            }
                                            callback.updateStatus(msg);
                                            callback.speak(msg);
                                        }});
                                    } else {
                                        int moved = aggregateManager.aggregateFiles(node.src, node.dst);
                                        if (moved == 0) throw new Exception("No files found to clear.");
                                    }
                                    break;
                                }
                                case "count": {
                                    final long[] res = aggregateManager.countFiles(node.src);
                                    final long count = res[0]; final String sz = Utils.formatFileSize(res[1]);
                                    final String extLabel = node.src.startsWith(".") ? node.src.substring(1).toUpperCase() : node.src.toUpperCase();
                                    activity.runOnUiThread(new Runnable() { @Override public void run() {
                                        String msg;
                                        if (count == 0) {
                                            msg = "You have no " + extLabel + " files. You might try a downloader app to get some.";
                                        } else {
                                            msg = "There are " + count + " " + extLabel + " files (" + sz + " total)";
                                        }
                                        callback.updateStatus(msg);
                                        callback.speak(msg);
                                    }});
                                    break;
                                }
                                case "find": case "locate": {
                                    final String found = searchManager.locateFile(node.src);
                                    if (found == null) throw new FileNotFoundException("Could not find: " + node.src);
                                    activity.runOnUiThread(new Runnable() { @Override public void run() { callback.showToast("Found at: " + found); } });
                                    break;
                                }
                                default: throw new UnsupportedOperationException("Unknown op: " + node.op);
                            }

                            // Output validation (unchanged)
                            File verifyDst = storageCore.resolve(node.dst);
                            FileValidator.validateOutput(node.op, rawFile, verifyDst);

                            node.status = "SUCCESS";
                            report.succeeded.add(node.op + ": " + node.src);

                        } catch (final Exception e) {
                            node.status = "FAILED";
                            node.failureReason = e.getMessage();
                            report.failed.add(node.op + " failed: " + e.getMessage());
                            // FIX #4 – speak only the real explanation, no generic prefix
                            activity.runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    String msg = e.getMessage();
                                    callback.updateStatus("Error: " + msg);
                                    callback.speak(msg);
                                }
                            });
                            break;
                        }
                    }

                    // FIX #4 – Only report "completed" if no failures, otherwise the failure messages already spoken
                    if (report.failed.isEmpty()) {
                        final String summary = report.buildSummaryString();
                        activity.runOnUiThread(new Runnable() {
                            @Override public void run() { callback.showToast(summary); callback.updateStatus("File operations completed successfully."); }
                        });
                    }
                }
            }).start();
        } catch (Exception e) {
            callback.showToast("Engine Failure: " + e.getMessage());
        }
    }

    // FIX #5 – simple check that the file is inside the external storage root
    private boolean isSafePath(File file) {
        // Allow only paths under the primary external storage directory.
        // Additional internal media directories (e.g. /storage/emulated/0/…) are under rootDir.
        return file.getAbsolutePath().startsWith(rootDir.getAbsolutePath());
    }
}