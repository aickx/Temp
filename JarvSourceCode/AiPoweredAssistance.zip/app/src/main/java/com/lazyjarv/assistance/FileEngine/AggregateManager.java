package com.lazyjarv.assistance.FileEngine;

import android.app.Activity;
import android.os.Environment;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class AggregateManager {

    public interface ProgressCallback {
        void onProgress(String message);
    }

    private final File rootDir = Environment.getExternalStorageDirectory();
    private final Activity activity;
    private final StorageCore storageCore;
    private final ProgressCallback progressCallback;

    public AggregateManager(Activity activity, StorageCore storageCore, ProgressCallback progressCallback) {
        this.activity = activity;
        this.storageCore = storageCore;
        this.progressCallback = progressCallback;
    }

    public long[] countFiles(String extension) {
        long[] result = new long[2];
        String ext = extension.toLowerCase().trim();
        if (!ext.startsWith(".")) ext = "." + ext;
        countFilesRecursive(rootDir, ext, result);
        return result;
    }

    private void countFilesRecursive(File dir, String ext, long[] result) {
        File[] files = dir.listFiles(); if (files == null) return;
        for (File f : files) {
            String name = f.getName();
            if (f.isDirectory()) {
                if (!name.startsWith(".") && !name.equalsIgnoreCase("Android"))
                    countFilesRecursive(f, ext, result);
            } else if (name.toLowerCase().endsWith(ext)) { result[0]++; result[1] += f.length(); }
        }
    }

    public int aggregateFiles(final String extension, String dstFolder) throws Exception {
        File destDir = new File(rootDir, dstFolder);
        if (!destDir.exists()) destDir.mkdirs();
        List<File> found = new ArrayList<>();
        scanForAggregation(rootDir, extension.toLowerCase().trim(), destDir.getAbsolutePath(), found);
        if (found.isEmpty()) return 0;
        int success = 0;
        for (int i = 0; i < found.size(); i++) {
            File src = found.get(i);
            final int cur = i + 1, total = found.size();
            if (i % 3 == 0 || i == found.size() - 1) {
                activity.runOnUiThread(new Runnable() {
                    @Override public void run() { progressCallback.onProgress("Moving " + extension + " files: " + cur + " / " + total); }
                });
            }
            String base = src.getName(), nameOnly = base, ext2 = "";
            int dot = base.lastIndexOf('.'); if (dot > 0) { nameOnly = base.substring(0, dot); ext2 = base.substring(dot); }
            File target = new File(destDir, base); int counter = 1;
            while (target.exists()) target = new File(destDir, nameOnly + "_(" + counter++ + ")" + ext2);
            storageCore.copyFileSingle(src, target);
            if (target.exists() && target.length() == src.length()) { success++; src.delete(); }
            else target.delete();
        }
        return success;
    }

    private void scanForAggregation(File dir, String ext, String destPath, List<File> results) {
        File[] files = dir.listFiles(); if (files == null) return;
        for (File f : files) {
            String name = f.getName();
            if (f.isDirectory()) {
                if (!name.startsWith(".") && !name.equalsIgnoreCase("Android") && !f.getAbsolutePath().equals(destPath))
                    scanForAggregation(f, ext, destPath, results);
            } else if (name.toLowerCase().endsWith(ext)) results.add(f);
        }
    }
}