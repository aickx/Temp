package com.lazyjarv.assistance;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

import org.json.*;

import java.io.InputStream;
import java.net.*;
import java.util.Scanner;

public class AIManager {

    public interface AICallback {
        void onSpeechReady(String speech);
        void onActionReady(JSONObject liveReply);
        void onError(String message);
        String getAppData();
        boolean shouldIncludeApps();
        void setIncludeApps(boolean value);
        void onNeedAppList(String userInput);
    }

    private final Activity activity;
    private final AICallback callback;
    private final MemoryManager memoryManager;

    private int appListRetryCount = 0;

    public AIManager(
            Activity activity,
            AICallback callback,
            MemoryManager memoryManager) {

        this.activity = activity;
        this.callback = callback;
        this.memoryManager = memoryManager;
    }

    public void send(
            final String userInput,
            final String apiKey,
            final String systemPrompt) {

        if (userInput == null || userInput.trim().isEmpty()) {

            callback.onError("No input!");
            return;
        }

        new Thread(new Runnable() {

            @Override
            public void run() {

                try {

                    JSONObject payload = new JSONObject();

                    JSONObject sysInstruction =
                            new JSONObject();

                    JSONArray sysParts =
                            new JSONArray();

                    sysParts.put(
                            new JSONObject()
                                    .put("text", systemPrompt));

                    sysInstruction.put("parts", sysParts);

                    payload.put(
                            "systemInstruction",
                            sysInstruction);

                    JSONArray contents =
                            new JSONArray();

                    for (String h :
                            memoryManager.getHistory()) {

                        try {

                            contents.put(
                                    new JSONObject(h));

                        } catch (Exception ignored) {
                        }
                    }

                    String combinedInput = userInput;

                    if (callback.shouldIncludeApps()) {

                        combinedInput +=
                                "\n\n[Installed Apps Directory]:\n"
                                        + callback.getAppData();

                        callback.setIncludeApps(false);
                    }

                    JSONObject userMsg =
                            new JSONObject();

                    JSONArray userParts =
                            new JSONArray();

                    userParts.put(
                            new JSONObject()
                                    .put("text", combinedInput));

                    userMsg.put("parts", userParts);
                    userMsg.put("role", "user");

                    contents.put(userMsg);

                    payload.put("contents", contents);

                    memoryManager.addUserTurn(userInput);

                    String url =
                            "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key="
                                    + apiKey;

                    HttpURLConnection conn =
                            (HttpURLConnection)
                                    new URL(url).openConnection();

                    conn.setRequestMethod("POST");

                    conn.setRequestProperty(
                            "Content-Type",
                            "application/json");

                    conn.setDoOutput(true);

                    conn.getOutputStream()
                            .write(payload.toString()
                                    .getBytes("UTF-8"));

                    final int code =
                            conn.getResponseCode();

                    InputStream is =
                            (code == 200)
                                    ? conn.getInputStream()
                                    : conn.getErrorStream();

                    Scanner scanner =
                            new Scanner(is)
                                    .useDelimiter("\\A");

                    final String response =
                            scanner.hasNext()
                                    ? scanner.next()
                                    : "";

                    new Handler(Looper.getMainLooper())
                            .post(new Runnable() {

                                @Override
                                public void run() {

                                    handleResponse(
                                            response,
                                            code,
                                            userInput);
                                }
                            });

                } catch (final Exception e) {

                    new Handler(Looper.getMainLooper())
                            .post(new Runnable() {

                                @Override
                                public void run() {

                                    callback.onError(
                                            "Connection Error: "
                                                    + e.getMessage());
                                }
                            });
                }
            }
        }).start();
    }

    private void handleResponse(
            String response,
            int code,
            String originalInput) {

        if (code != 200) {

            callback.onError("API Error: " + code);
            return;
        }

        try {

            JSONObject base =
                    new JSONObject(response);

            String raw =
                    base.getJSONArray("candidates")
                            .getJSONObject(0)
                            .getJSONObject("content")
                            .getJSONArray("parts")
                            .getJSONObject(0)
                            .getString("text");

            if (raw.contains("```json")) {

                raw =
                        raw.substring(
                                raw.indexOf("```json") + 7);

                if (raw.contains("```")) {

                    raw =
                            raw.substring(
                                    0,
                                    raw.indexOf("```"));
                }

            } else if (raw.contains("```")) {

                raw =
                        raw.substring(
                                raw.indexOf("```") + 3);

                if (raw.contains("```")) {

                    raw =
                            raw.substring(
                                    0,
                                    raw.indexOf("```"));
                }
            }

            raw = raw.trim();

            JSONObject reply =
                    new JSONObject(raw);

            String action =
                    reply.optString("action", "");

            if ("NEED_APP_LIST".equals(action)) {

                if (appListRetryCount >= 1) {

                    appListRetryCount = 0;

                    callback.onError(
                            "System Error: App list too large.");

                    return;
                }

                appListRetryCount++;

                callback.setIncludeApps(true);

                callback.onNeedAppList(originalInput);

                return;
            }

            appListRetryCount = 0;

            String speech =
                    reply.optString("speech", "");

            if (!speech.isEmpty()) {

                callback.onSpeechReady(speech);
            }

            memoryManager.addModelTurn(raw);

            callback.onActionReady(reply);

        } catch (Exception e) {

            callback.onError(
                    "Portal Error: " + e.getMessage());
        }
    }
}