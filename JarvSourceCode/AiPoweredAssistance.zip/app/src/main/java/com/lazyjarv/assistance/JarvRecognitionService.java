package com.lazyjarv.assistance;

import android.content.Intent;
import android.speech.RecognitionService;

public class JarvRecognitionService extends RecognitionService {
    @Override
    protected void onStartListening(Intent recognizerIntent, Callback listener) {
        // Abstract method requirement satisfied
    }

    @Override
    protected void onCancel(Callback listener) {
        // Abstract method requirement satisfied
    }

    @Override
    protected void onStopListening(Callback listener) {
        // Abstract method requirement satisfied
    }
}
